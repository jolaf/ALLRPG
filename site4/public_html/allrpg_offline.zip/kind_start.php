<?php

if($action=="import" && file_exists($server_inner_path.'import/'.encode($_GET["file"]))) {	require_once($server_inner_path.'import/'.encode($_GET["file"]));
    import($prefix."sites",$sites,$sites_structure);
    import($prefix."roles",$roles,$roles_structure,$sites[0][0]);
    import($prefix."rolescomments",$rolescomments,$rolescomments_structure,$sites[0][0]);
    import($prefix."roleslocat",$roleslocat,$roleslocat_structure,$sites[0][0]);
    import($prefix."rolevacancy",$rolevacancy,$rolevacancy_structure,$sites[0][0]);
    import($prefix."roleslinks",$roleslinks,$roleslinks_structure,$sites[0][0]);
    import($prefix."rolefields",$rolefields,$rolefields_structure,$sites[0][0]);
    $result=mysql_query("SELECT * from ".$prefix."roleslocat");
	while($a=mysql_fetch_array($result)) {
		if($a["parent"]!=0) {
			$result2=mysql_query("SELECT * from ".$prefix."roleslocat where allrpg_id=".$a["parent"]);
			$b=mysql_fetch_array($result2);
			mysql_query("UPDATE ".$prefix."roleslocat SET parent=".$b["id"]." where id=".$a["id"]);
		}
	}
	$result=mysql_query("SELECT * from ".$prefix."rolefields");
	while($a=mysql_fetch_array($result)) {		$rolefieldchange[]=Array($a["allrpg_id"],$a["id"]);
	}
	$result=mysql_query("SELECT * from ".$prefix."roles");
	while($a=mysql_fetch_array($result)) {
		$result2=mysql_query("SELECT * from ".$prefix."roleslocat where allrpg_id=".$a["locat"]);
		$b=mysql_fetch_array($result2);
		if($b["id"]!='') {
			mysql_query("UPDATE ".$prefix."roles SET locat=".$b["id"]." where id=".$a["id"]);
		}
		$result2=mysql_query("SELECT * from ".$prefix."rolevacancy where allrpg_id=".$a["vacancy"]);
		$b=mysql_fetch_array($result2);
		if($b["id"]!='') {
			mysql_query("UPDATE ".$prefix."roles SET vacancy=".$b["id"]." where id=".$a["id"]);
		}
		$change=$a["allinfo"];
		for($i=0;$i<count($rolefieldchange);$i++) {			$change=str_replace('[virtual'.$rolefieldchange[$i][0].']','[virtual'.$rolefieldchange[$i][1].']',$change);
		}
		mysql_query("UPDATE ".$prefix."roles SET allinfo='".$change."' where id=".$a["id"]);
	}
	$result=mysql_query("SELECT * from ".$prefix."rolevacancy");
	while($a=mysql_fetch_array($result)) {
		$result2=mysql_query("SELECT * from ".$prefix."roleslocat where allrpg_id=".$a["locat"]);
		$b=mysql_fetch_array($result2);
		mysql_query("UPDATE ".$prefix."rolevacancy SET locat=".$b["id"]." where id=".$a["id"]);
	}
	$result=mysql_query("SELECT * from ".$prefix."rolescomments");
	while($a=mysql_fetch_array($result)) {
		$result2=mysql_query("SELECT * from ".$prefix."roles where allrpg_id=".$a["role_id"]);
		$b=mysql_fetch_array($result2);
		mysql_query("UPDATE ".$prefix."rolescomments SET role_id=".$b["id"]." where id=".$a["id"]);
	}
	$result=mysql_query("SELECT * from ".$prefix."roleslinks");
	while($a=mysql_fetch_array($result)) {
		if($a["parent"]!=0) {			$result2=mysql_query("SELECT * from ".$prefix."roleslinks where allrpg_id=".$a["parent"]);
			$b=mysql_fetch_array($result2);
			mysql_query("UPDATE ".$prefix."roleslinks SET parent=".$b["id"]." where id=".$a["id"]);
		}
		if($a["vacancies"]!='') {
			unset($vacancies);
			$vacancies=substr($a["vacancies"],1,strlen($vacancies)-1);
			$vacancies=explode('-',$vacancies);
			$vacanciesnew='-';
	        foreach($vacancies as $v) {
				if($v==0) {					$vacanciesnew.='0-';
				}
				else {
					$result2=mysql_query("SELECT * from ".$prefix."rolevacancy where allrpg_id=".$v);
					$b=mysql_fetch_array($result2);
					$vacanciesnew.=$b["id"].'-';
				}
			}
			if($vacanciesnew!='-') {
				mysql_query("UPDATE ".$prefix."roleslinks SET vacancies='".$vacanciesnew."' where id=".$a["id"]);
			}
		}
		if($a["roles"]!='' && $a["roles2"]!='') {
			unset($roles);
			unset($roles2);
			$roles=substr($a["roles"],1,strlen($roles)-1);
			$roles2=substr($a["roles2"],1,strlen($roles2)-1);
			$roles=explode('-',$roles);
			$roles2=explode('-',$roles2);
			$rolesnew='-';
			$roles2new='-';
			foreach($roles as $r) {				if(strpos($r,'all')!==false) {					$r=preg_replace('#all#','',$r);
					if($r==0) {						$rolesnew.='all0-';
					}
					else {						$result2=mysql_query("SELECT * from ".$prefix."rolevacancy where allrpg_id=".$r);
						$b=mysql_fetch_array($result2);
						$rolesnew.='all'.$b["id"].'-';
					}
				}
				else {					$result2=mysql_query("SELECT * from ".$prefix."roles where allrpg_id=".$r);
					$b=mysql_fetch_array($result2);
					$rolesnew.=$b["id"].'-';
				}
			}
			foreach($roles2 as $r) {
				if(strpos($r,'all')!==false) {
					$r=preg_replace('#all#','',$r);
					if($r==0) {
						$roles2new.='all0-';
					}
					else {
						$result2=mysql_query("SELECT * from ".$prefix."rolevacancy where allrpg_id=".$r);
						$b=mysql_fetch_array($result2);
						$roles2new.='all'.$b["id"].'-';
					}
				}
				else {
					$result2=mysql_query("SELECT * from ".$prefix."roles where allrpg_id=".$r);
					$b=mysql_fetch_array($result2);
					$roles2new.=$b["id"].'-';
				}
			}
			mysql_query("UPDATE ".$prefix."roleslinks SET roles='".$rolesnew."', roles2='".$roles2new."' where id=".$a["id"]);
		}
	}
	$result=mysql_query("SELECT * from ".$prefix."sites WHERE allrpg_id=".$sites[0][0]);
	$a=mysql_fetch_array($result);
	$result2=mysql_query("SELECT * from ".$prefix."rolefields where allrpg_id=".$a["sorter"]);
	$b=mysql_fetch_array($result2);
	if($b["id"]!='') {
		mysql_query("UPDATE ".$prefix."sites SET sorter=".$b["id"]." where id=".$a["id"]);
	}
	$result2=mysql_query("SELECT * from ".$prefix."rolefields where allrpg_id=".$a["sorter2"]);
	$b=mysql_fetch_array($result2);
	if($b["id"]!='') {
		mysql_query("UPDATE ".$prefix."sites SET sorter2=".$b["id"]." where id=".$a["id"]);
	}
	err("������ ������� ������� ��������.");
}
elseif($action=="delete" && file_exists($server_inner_path.'import/'.encode($_GET["file"]))) {	unlink($server_inner_path.'import/'.encode($_GET["file"])) or die('File could not be deleted!');
	err("���� ������� ������.");
}

//������ ��������� ��������
$content2.='<center><div class="cb_editor" style="width: 645;">
<h1>�������� ������</h1>
<table class="menutable"><tr><td class="menu">��������</td></tr>';
$i=0;
$result=mysql_query("SELECT * from ".$prefix."sites order by title");
while($a=mysql_fetch_array($result)) {	if($i%2==0) {		$content2.='<tr class="string1">';
	}
	else {		$content2.='<tr class="string2">';
	}
	$content2.='<td><a href="'.$server_absolute_path.'orders/site='.$a["allrpg_id"].'">'.decode($a["title"]).'</a></td></tr>';
}
$content2.='</table><br>';

//������ ������, ������� � �������� import
$content2.='<h1>������������� �� �����</h1>
<table class="menutable"><tr><td class="menu">����</td></tr>';
$content2.=show_dir($server_inner_path.'import/');
$content2.='</table>
</div></center>';

function import($table,$dataarray,$datastructure,$siteid) {	$exclude_ids='';
	for($i=0;$i<count($dataarray);$i++) {		$exclude_ids.=$dataarray[$i][0].', ';
		$result=mysql_query("SELECT id from ".$table." where allrpg_id=".$dataarray[$i][0]);
		$a=mysql_fetch_array($result);
		if($a["id"]=='') {			$query="INSERT INTO ".$table." (";
			for($j=0;$j<count($datastructure);$j++) {				$query.=$datastructure[$j][0].', ';
			}
			$query=substr($query,0,strlen($query)-2);
			$query.=") VALUES (";
            for($j=0;$j<count($datastructure);$j++) {
				if($datastructure[$j][1]) {					$query.=$dataarray[$i][$j].', ';
				}
				else {					$query.='"'.$dataarray[$i][$j].'", ';
				}
			}
			$query=substr($query,0,strlen($query)-2);
			$query.=")";
		}
		else {			$query="UPDATE ".$table." SET ";
            for($j=0;$j<count($datastructure);$j++) {
				if($datastructure[$j][1]) {
					$query.=$datastructure[$j][0].'='.$dataarray[$i][$j].', ';
				}
				else {
					$query.=$datastructure[$j][0].'="'.$dataarray[$i][$j].'", ';
				}
			}
			$query=substr($query,0,strlen($query)-2);
			$query.=" WHERE allrpg_id=".$dataarray[$i][0];
		}
		mysql_query($query) or die("��� ������� ������ �������� ������.<br />������: ".$query."<br /> ������: (".mysql_errno().") ".mysql_error());
	}
	$exclude_ids=substr($exclude_ids,0,strlen($exclude_ids)-2);
	if($siteid>0) {
		if(strlen($exclude_ids)>0) {
			mysql_query("DELETE from ".$table." where allrpg_id>0 and site_id=".$siteid." and allrpg_id NOT IN (".$exclude_ids.")");
		}
	}
}

function show_dir($dir){
   	global
		$server_absolute_path;

    $i=0;
    $handle = @opendir($dir);
    while ($file = @readdir ($handle))
	{
		if(preg_match("/^\\.{1,2}$/",$file)) {
			continue;
		}
        if($i%2==0) {
			$res.='<tr class="string1">';
		}
		else {
			$res.='<tr class="string2">';
		}
		$res.='<td><a OnClick="if (confirm(\'�� �������, ��� ������ ������������� ������ ����? ������ � ����, ����� ��������������� � allrpg.info, ����� �������� �� ����� ��� ����������� �� ����, ��������� �� � ��� �������� ���������. ��� �������� ����������.\')) {document.location=\''.$server_absolute_path.'action=import&file='.$file.'\';}" style="cursor: pointer;">'.$file.'</a> [<a OnClick="if (confirm(\'�� �������, ��� ������ ������� ������ ����?\')) {document.location=\''.$server_absolute_path.'action=delete&file='.$file.'\';}" style="cursor: pointer;">�������</a>]</td></tr>';
    }
    @closedir($handle);

    return($res);
}
?>