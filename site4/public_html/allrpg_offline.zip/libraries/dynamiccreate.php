<?php
function dynamiccreate($obj) {
	global
		$kind,
		$object,
		$id,
		$page,
		$act,
		$actiontype,
		$valuestype,
		$sorting,
		$trouble,
		$trouble2,
		$formfile,
		$stayhere,
		$server_absolute_path,
		$direct,
		$admin,
		$curdir,
		$onloadfunc,
		$error;

	$grads=$obj->getElemPerPage();
	$this_type=$obj->getType();
	$this_right=$obj->getRight();
	$this_sort=$obj->getSort();
	$this_search=$obj->getSearch();
	$this_table=$obj->getTable();
	$filds=$obj->getElems();

	if($trouble || $trouble2[-1])
	{
		if($actiontype=="add")
		{
			$act="add";
		}
	}

	if(!isset($stayhere)) {
		$stayhere=true;
		if($act=="view" && !$trouble && $actiontype=="change") {
			$stayhere=false;
		}
		elseif(!$trouble && $actiontype=="add") {
			$stayhere=false;
		}
		elseif(!$trouble && $actiontype=="delete") {
			$stayhere=false;
		}
	}

	if($this_search[0]!='' && $this_right->getView())
	{
		require_once("filters.php");
	}

	if(((($this_type==2 || $this_type==3) && ($act=='' || ($act=="view" && !$stayhere))) || $this_type==1) && $this_right->getView())
	{
		$order='';
		$homos='t1.';
		$homos2='';
		$homos3='';
		$homcount=2;
		$sorting2=0;

		if($this_right->getViewRestrict()!='')
		{
			$homos3=str_ireplace(' and ',' and '.$homos,$this_right->getViewRestrict());
			$homos3=str_ireplace(' or ',' or '.$homos,$homos3);
			$homos3=" WHERE ".$homos.$homos3;
		}

		if($sorting!='')
		{
			$sorting2=round($sorting/2)-1;
			if($sorting%2==1)
			{
				$sorting3="ASC";
			}
			else
			{
				$sorting3="DESC";
			}
		}

		for($i=0;$i<count($this_sort[0]);$i++)
		{
			if($this_sort[0][$i][4][0]==3)
			{
				$homos2.=' LEFT JOIN '.$this_sort[0][$i][4][1].' t'.$homcount.' ON t1.'.$this_sort[0][$i][0].'=t'.$homcount.'.'.$this_sort[0][$i][4][2];
				if($i==$sorting2 && $sorting!=0)
				{
					$order='t'.$homcount.'.'.$this_sort[0][$i][4][3].' '.$sorting3.', '.$order;
				}
				else
				{
					$order.='t'.$homcount.'.'.$this_sort[0][$i][4][3].' '.$this_sort[0][$i][1].', ';
				}
				$homcount++;
			}
			elseif($this_sort[0][$i][4][0]==2)
			{
				$ordfield='FIELD('.$homos.$this_sort[0][$i][0];
				for($j=0;$j<count($this_sort[0][$i][4][1]);$j++) {
					$ordfield.=", '".$this_sort[0][$i][4][1][$j][0]."'";
				}
				$ordfield.=')';
				if($i==$sorting2 && $sorting!=0)
				{
					$order=$ordfield.' '.$sorting3.', '.$order;
				}
				else
				{
					$order.=$ordfield.' '.$this_sort[0][$i][1].', ';
				}
			}
			else
			{
				if($i==$sorting2 && $sorting!=0)
				{
					$order=$homos.$this_sort[0][$i][0].' '.$sorting3.', '.$order;
				}
				else
				{
					$order.=$homos.$this_sort[0][$i][0].' '.$this_sort[0][$i][1].', ';
				}
			}
		}
		$order=substr($order,0,strlen($order)-2);
		if($this_type!=3)
		{
			if($this_right->getViewRestrict()!='' && $_SESSION['indexers'][$kind][$obj->getName()]['searchquery']!='')
			{
				$query="SELECT t1.* FROM ".$this_table." t1".$homos2.$homos3.' AND'.$_SESSION['indexers'][$kind][$obj->getName()]['searchquery']." ORDER by ".$order." LIMIT ".($page*$grads).", ".$grads;
				$result=mysql_query("SELECT COUNT(t1.id) FROM ".$this_table." t1".$homos2.$homos3.' AND'.$_SESSION['indexers'][$kind][$obj->getName()]['searchquery']." ORDER by ".$order);
			}
			else
			{
				$query="SELECT t1.* FROM ".$this_table." t1".$homos2.$homos3.$_SESSION['indexers'][$kind][$obj->getName()]['searchquery']." ORDER by ".$order." LIMIT ".($page*$grads).", ".$grads;
				$result=mysql_query("SELECT COUNT(t1.id) FROM ".$this_table." t1".$homos2.$homos3.$_SESSION['indexers'][$kind][$obj->getName()]['searchquery']." ORDER by ".$order);
			}
			$a = mysql_fetch_array($result);
			$pagetotal=$a[0];
		}
		else
		{
			$type3_foundids=' ';
			$type3_foundparents=' ';
			if($this_right->getViewRestrict()!='' && $_SESSION['indexers'][$kind][$obj->getName()]['searchquery']!='')
			{
				$query="SELECT t1.* FROM ".$this_table." t1".$homos2.$homos3.' AND'.$_SESSION['indexers'][$kind][$obj->getName()]['searchquery']." ORDER by ".$order;
			}
			else
			{
				$query="SELECT t1.* FROM ".$this_table." t1".$homos2.$homos3.$_SESSION['indexers'][$kind][$obj->getName()]['searchquery']." ORDER by ".$order;
			}
			$result=mysql_query($query);
			function type3_foundparents($this_table, $parent, $id) {
				$result=mysql_query("SELECT * FROM ".$this_table." where id=".$id);
				$a = mysql_fetch_array($result);
				if($a[$parent]>0)
				{
					$type3_foundparents=type3_foundparents($this_table, $parent, $a[$parent]);
					$type3_foundparents.=$a[$parent].', ';
				}
				return $type3_foundparents;
			}
			function type3_foundchilds($this_table, $parent, $id) {
				$result=mysql_query("SELECT * FROM ".$this_table." where ".$parent."=".$id);
				while($a = mysql_fetch_array($result)) {
					$type3_foundchilds.=type3_foundchilds($this_table, $parent, $a["id"]);
					$type3_foundchilds.=$a["id"].', ';
				}
				return $type3_foundchilds;
			}
			while($a = mysql_fetch_array($result))
			{
				$type3_foundids.=$a["id"].', ';
				if($_SESSION['indexers'][$kind][$obj->getName()]['searchquery']!='' && $a[$obj->getParent()]>0) {
					$type3_foundparents.=type3_foundparents($this_table, $obj->getParent(), $a["id"]);
				}
				elseif($_SESSION['indexers'][$kind][$obj->getName()]['searchquery']!='' && $a[$obj->getParent()]==0 && $_SESSION['indexers'][$kind][$obj->getName()]['search_showchilds']=='on') {
					$type3_foundids.=type3_foundchilds($this_table, $obj->getParent(), $a["id"]);
				}
			}
			$countquery="SELECT COUNT(id) FROM ".$this_table." where ";
			if($type3_foundids!=' ')
			{
				$countquery.="id IN (".substr($type3_foundids,0,strlen($type3_foundids)-2).")";
				if($type3_foundparents!=' ')
				{
					$countquery.=" OR id IN (".substr($type3_foundparents,0,strlen($type3_foundparents)-2).")";
				}
			}
			$result=mysql_query($countquery);
			$a = mysql_fetch_array($result);
			$pagetotal=$a[0];
		}
		//echo("<!--".$query."-->");
	}

	if($this_type==1 && $this_right->getView())
	{
		$type1columns=1;
		if($this_right->getDelete())
		{
			$type1columns+=1;
		}

		$content.='<center><div class="cb_editor"';
		if($obj->getSize()>40)
		{
			$content.=' style="width: '.$obj->getSize().';"';
		}
		$content.='><!-- start '.$obj->getName().' object -->
<center><table class="maininfotable" width="100%">
<tr class="menu">
';
		for($i=0;$i<($type1columns-1);$i++)
		{
			$content.='<td width=20>
&nbsp;
</td>
';
		}
		$content.='<td width=20>�</td>';

		$help='';
		$h=1;
		foreach($filds as $f=>$v)
		{
			if($v->getRead()<=$this_right->getRights())
			{
				$letdo=true;
				if($v->getType()=="timestamp")
				{
					if($v->getShow()==false) {
						$letdo=false;
					}
				}
				if($v->getType()=="hidden")
				{
					$letdo=false;
				}
				if($letdo)
				{
					$fs=false;
					$content.='<td>
';
					for($u=0;$u<count($this_sort['0']);$u++)
					{
						if($v->getName()==$this_sort['0'][$u][0])
						{
							if($sorting==($u*2+1))
							{
								$content.='<a href="'.$curdir.$kind.'/'.$obj->getName().'/page='.$page.'&sorting='.($u*2+2).'" title="[������������� : '.strtolower($v->getSname()).' : �� ��������]" onMouseOver="document.getElementById(\'arrow\').src=\''.$server_absolute_path.$direct.'/down.gif\'" onMouseOut="document.getElementById(\'arrow\').src=\''.$server_absolute_path.$direct.'/up.gif\'">'.$v->getSname().'</a> <img src="'.$server_absolute_path.$direct.'/up.gif" id="arrow" />';
							}
							elseif($sorting==($u*2+2))
							{
								$content.='<a href="'.$curdir.$kind.'/'.$obj->getName().'/page='.$page.'&sorting='.($u*2+1).'" title="[������������� : '.strtolower($v->getSname()).' : �� �����������]" onMouseOver="document.getElementById(\'arrow\').src=\''.$server_absolute_path.$direct.'/up.gif\'" onMouseOut="document.getElementById(\'arrow\').src=\''.$server_absolute_path.$direct.'/down.gif\'">'.$v->getSname().'</a> <img src="'.$server_absolute_path.$direct.'/down.gif" id="arrow" />';
							}
							else
							{
								$content.='<a href="'.$curdir.$kind.'/'.$obj->getName().'/page='.$page.'&sorting='.($u*2+2).'" title="[������������� : '.strtolower($v->getSname()).' : �� ��������]">'.$v->getSname().'</a>';
							}
							$fs=true;
						}
					}
					if(!$fs)
					{
						$content.=$v->getSname();
					}
					if($v->getMustBe() || $v->getHelp()!='') {						$content.='<span class="sup">';
					}
					if($v->getMustBe())
					{
						$content.=' *';
						$havetobehelp=true;
					}
					if($v->getHelp()!='') {
						$help.='<span class="sup">';
						$content.=' '.$h;
						$help.=$h;
						$help.='</span> � ';
						$help.=$v->getHelp().'<br />';
						$h++;
					}
					if($v->getMustBe() || $v->getHelp()!='') {
						$content.='</span>';
					}
					$content.='
</td>
';
					$type1columns+=1;
				}
			}
		}
		if($havetobehelp)
		{
			$help='<span class="sup">*</span> � ���� ���������� ���������.<br />'.$help;
		}
		$content.='</tr>
';
		if($this_right->getAdd())
		{
			$content.='<tr';
			if($trouble2[-1])
			{
				$content.=' class="type1red"';
			}
			$content.='>
<form action="'.$curdir.$kind.'/" method="post" enctype="multipart/form-data">
<input type="hidden" name="kind" value="'.$kind.'" />
<input type="hidden" name="object" value="'.$obj->getName().'" />
<input type="hidden" name="action" value="dynamicaction" />
<input type="hidden" name="page" value="'.$page.'" />
<input type="hidden" name="sorting" value="'.$sorting.'" />
<input type="hidden" name="actiontype" value="add" />
<input type="hidden" name="valuestype" value="'.$valuestype.'" />';
			if($this_right->getDelete())
			{
				$content.='
<td width=1>
<img src="'.$server_absolute_path.$direct.'/empty.gif" width="20" />
</td>';
			}
			$content.='
<td width=1>
<img src="'.$server_absolute_path.$direct.'/empty.gif" width="20" />
</td>
';
			foreach($filds as $f=>$v)
			{
				if($v->getType()!='')
				{
					if($v->getWrite()<=$this_right->getRights())
					{
						$can="write";
					}
					elseif($v->getRead()<=$this_right->getRights())
					{
						$can="read";
					}
					else
					{
						$can="";
					}

					if($can!='' && !($v->getType()=="timestamp" && !$v->getShow()) && $v->getType()!="hidden")
					{
						if($v->getWidth()!='')
						{
							$content.='<td width="'.($v->getWidth()+2).'">
';
						}
						else
						{
							$content.='<td>
';
						}
					}
					if($trouble2[-1])
					{
						$v->setVal('',true);
					}
					else
					{
						$v->setVal('');
					}
					if(!(($v->getType()=="select" || $v->getType()=="multiselect") && count($v->getValues())==0 && $v->getMustBe()==false))
					{
						$content.=$v->draw($this_type,$can);
					}
					if($can!='' && !($v->getType()=="timestamp" && !$v->getShow()) && $v->getType()!="hidden")
					{
						$content.='
</td>
';
					}
				}
			}

			$content.='</tr>
<tr class="menu">
<td colspan='.$type1columns.' style="text-align: right">
<span class="gui-btn"><span><span>�������� '.$obj->getWord1().'</span><input type="submit" onSubmit="this.disabled=true" /></span></span>
</td>
</form>
</tr>
';
		}

		if($this_right->getView())
		{
			$linenum=1;
			if($this_right->getChange())
			{
				$content.='<tr>
<td colspan='.$type1columns.' style="text-align: center"><h3 style="margin: 10px">��������</h3></td>
</tr>
<form action="'.$curdir.$kind.'/" method="post" enctype="multipart/form-data">
<input type="hidden" name="kind" value="'.$kind.'" />
<input type="hidden" name="object" value="'.$obj->getName().'" />
<input type="hidden" name="action" value="dynamicaction" />
<input type="hidden" name="actiontype" value="change" />
<input type="hidden" name="act" value="view" />
<input type="hidden" name="page" value="'.$page.'" />
<input type="hidden" name="sorting" value="'.$sorting.'" />
<input type="hidden" name="valuestype" value="'.$valuestype.'" />';
			}

			$result=mysql_query($query);
			while($a = mysql_fetch_array($result))
			{
				if($obj->getVirtualField()!='')
				{
					$a=array_merge($a,unmakevirtual($a[$obj->getVirtualField()]));
				}

				$content.='<tr class="';
				if($trouble2[$a["id"]]) {
					$content.='type1red';
				}
				else {
					if($linenum%2==0) {						$content.='string2';
					}
					else {						$content.='string1';
					}
				}
				$content.='">';
				if($this_right->getChange())
				{
					$content.='
<input type="hidden" name="id['.$linenum.']" value="'.$a["id"].'" />
';
				}

				if($this_right->getDelete())
				{
					$content.='<td>
<img src="'.$server_absolute_path.$direct.'/delete.gif" style="cursor: pointer" border="1" title="������� '.$obj->getWord1().'" OnClick="if (confirm(\'�� �������, ��� ������ ������� '.$obj->getWord1().'?\')){ document.location=\''.$curdir.$kind.'/'.$obj->getName().'/'.$a["id"].'/action=dynamicaction&actiontype=delete&act=view&page='.$page.'&sorting='.$sorting.'\'}" /></td>';
				}

				$content.='<td>'.$linenum.'</td>';

				foreach($filds as $f=>$v)
				{
					if($v->getType()!='')
					{
						if($v->getWrite()<=$this_right->getRights() && $this_right->getChange())
						{
							$can="write";
						}
						elseif($v->getRead()<=$this_right->getRights())
						{
							$can="read";
						}
						else
						{
							$can="";
						}

						if($can!='' && !($v->getType()=="timestamp" && !$v->getShow()) && $v->getType()!="hidden")
						{
							$content.='<td>
';
						}
						if($trouble2[$a["id"]])
						{
							if($can=="read") {								$v->setVal($a);
							}
							else {
								$v->setVal('',true,$linenum);
							}
						}
						else
						{
							$v->setVal($a);
						}
						$oldid=$id;
						$oldobject=$object;
						$object=$obj->getName();
						if(!(($v->getType()=="select" || $v->getType()=="multiselect") && count($v->getValues())==0 && $v->getMustBe()==false))
						{
							$id=$a["id"];
							$content.=$v->draw($this_type,$can,$linenum);
						}
						$id=$oldid;
						$object=$oldobject;
						if($can!='' && !($v->getType()=="timestamp" && !$v->getShow()) && $v->getType()!="hidden")
						{
							$content.='
</td>
';
						}
					}
				}

				$content.='
</tr>';
				$linenum++;
			}
			$content.='<tr class="menu">
<td colspan='.$type1columns.' style="text-align: right">';
			if($this_right->getChange())
			{
				$content.='
<input type="hidden" name="linecount" value="'.$linenum.'" />
<span class="gui-btn"><span><span>��������� ���������</span><input type="submit" name="saveall" onSubmit="this.disabled=true" /></span></span></form>';
			}
			else
			{
				$content.='&nbsp;';
			}
			$content.='</td>
</tr>';
		}
		if($help!='')
		{
			$content.='
<tr>
<td colspan='.$type1columns.' style="text-align: justify" class="sm2"><a name="help"></a>'.$help.'</td>
</tr>
<tr class="menu">
<td colspan='.$type1columns.'>&nbsp;</td>
</tr>';
		}
		$content.='
</table></center>';
	}
	else
	{
		if($id!='' && (($action!="dynamicaction" && $actiontype!="delete") || $stayhere)) {
			$result=mysql_query("SELECT * FROM ".$this_table." WHERE id=".$id);
			$a = mysql_fetch_array($result);
			if($a["id"]=='') {
				$this_right->setView(false);
				$this_right->setChange(false);
				$this_right->setDelete(false);
			}

			if($this_right->getViewRestrict()!='') {
				$result=mysql_query("SELECT * FROM ".$this_table." WHERE id=".$id." AND ".$this_right->getViewRestrict());
				$a = mysql_fetch_array($result);
				if($a["id"]=='') {
					$this_right->setView(false);
				}
			}
			if($this_right->getChangeRestrict()!='') {
				$result=mysql_query("SELECT * FROM ".$this_table." WHERE id=".$id." AND ".$this_right->getChangeRestrict());
				$a = mysql_fetch_array($result);
				if($a["id"]=='') {
					$this_right->setChange(false);
				}
			}
			if($this_right->getDeleteRestrict()!='') {
				$result=mysql_query("SELECT * FROM ".$this_table." WHERE id=".$id." AND ".$this_right->getDeleteRestrict());
				$a = mysql_fetch_array($result);
				if($a["id"]=='') {
					$this_right->setDelete(false);
				}
			}
		}

		if($act=="add" && $this_right->getAdd())
		{
			$content.='
<form action="'.$curdir.$kind.'/" method="post" enctype="multipart/form-data">
<input type="hidden" name="kind" value="'.$kind.'" />
<input type="hidden" name="object" value="'.$obj->getName().'" />
<input type="hidden" name="action" value="dynamicaction" />
<input type="hidden" name="actiontype" value="add" />
<input type="hidden" name="valuestype" value="'.$valuestype.'" />

<center><div class="cb_editor"';
			if($obj->getSize()>40)
			{
				$content.=' style="width: '.$obj->getSize().';"';
			}
			$content.='><!-- start '.$obj->getName().' object -->
';
		}
		elseif($act=="view" && $stayhere && $this_right->getView())
		{
			if($this_right->getViewRestrict()!='')
			{
				$result=mysql_query("SELECT * FROM ".$this_table." WHERE id=".$id." AND (".$this_right->getViewRestrict().")");
			}
			else
			{
				$result=mysql_query("SELECT * FROM ".$this_table." WHERE id=".$id);
			}
			$a = mysql_fetch_array($result);

			if($obj->getVirtualField()!='')
			{
				$a=array_merge($a,unmakevirtual($a[$obj->getVirtualField()]));
			}

			if($this_right->getChange())
			{
				$content.='
<form action="'.$curdir.$kind.'/" method="post" enctype="multipart/form-data">
<input type="hidden" name="kind" value="'.$kind.'" />
<input type="hidden" name="object" value="'.$obj->getName().'" />
<input type="hidden" name="action" value="dynamicaction" />
<input type="hidden" name="actiontype" value="change" />
<input type="hidden" name="act" value="view">
<input type="hidden" name="id" value="'.$id.'" />
<input type="hidden" name="valuestype" value="'.$valuestype.'" />';
			}

			$content.='
<center><div class="cb_editor"';

			if($obj->getSize()>40)
			{
				$content.=' style="width: '.$obj->getSize().';"';
			}
			$content.='><!-- start '.$obj->getName().' object -->
';
		}

		if(($act=="view" && $this_right->getView() && $stayhere) || ($act=="add" && $this_right->getAdd()))
		{
			if($valuestype=="1")
			{
				$h=$obj->getElems2();
			}
			else
			{
				$h=$filds;
			}
			foreach($h as $f=>$v)
			{
				if((($act=="add" && $this_right->getAdd()) || ($act=="view" && $stayhere && $this_right->getChange())) && $v->getWrite()<=$this_right->getRights())
				{
					$can="write";
				}
				elseif($v->getRead()<=$this_right->getRights())
				{
					$can="read";
				}
				else
				{
					$can="";
				}

				if($trouble && $can=="write")
				{
					$v->setVal('',true);
				}
				else
				{
					$v->setVal($a);
				}
				if($can && (!($can=="read" && ($v->getVal()=='' || ($v->getType()=="multiselect" && ($v->getVal()=='-' || $v->getVal()=='--')) || ($v->getType()=="select" && $v->getVal()==0))) || ($v->getType()=="h1" && ($can=="read" || $can=="write"))) && !(($v->getType()=="select" || $v->getType()=="multiselect") && count($v->getValues())==0 && $v->getMustBe()==false))
				{
					if($v->getType()!="hidden" && $v->getType()!="timestamp" && $v->getType()!="h1") {
						if($v->getType()!="sarissa" || ($v->getType()=="sarissa" && $can=="write")) {
							$content.='<div class="fieldname">';
		                    if($v->getType()=="checkbox" && $can=="write") {								$content.='<label for="'.$v->getName().'">';
							}
							if($trouble && $stayhere && in_array($v->getSname(),$trouble2)) {								$content.='<span class="type2red">'.$v->getSname().'</span>';
							}
							else {								$content.=$v->getSname();
							}
							if($v->getType()=="checkbox" && $can=="write") {								$content.='</label>';
							}
							if($can=="write") {
								if($v->getMustBe()) {
									$content.='<span class="mustbe"> � ���������� ���������</span>';
								}
								if($v->getHelp()!='') {
									$content.='<br /><span class="help">'.$v->getHelp().'</span>';
								}
							}
							$content.='</div>';
						}
					}

					$content.=$v->draw($this_type,$can);

					if($v->getType()!="hidden" && $v->getType()!="timestamp" && $v->getType()!="h1")
					{
						if($can!='') {
							if(($v->getType()=="multiselect" && $v->getOne()==false) || ($v->getType()=="wysiwyg" && $can=="write")) {
								$content.='<br />
';
							}
							else {
								$content.='<br /><br />
';
							}
						}
					}
				}
			}
			$content.='
<!-- end '.$obj->getName().' object --></div>
<br />
';
		}

		if($act=="add")
		{
			if($this_right->getAdd()) {
				$content.='<span class="gui-btn"><span><span>�������� ';
				if($valuestype=="0") {
					$content.=$obj->getWord1();
				}
				else {
					$content.=$obj->getWord3();
				}
				$content.='</span><input type="submit" onSubmit="this.disabled=true" /></span></span></center>
</form>';
			}
		}
		elseif($act=="view" && $stayhere)
		{
			if($this_right->getChange())
			{
				$content.='<span class="gui-btn"><span><span>��������� ';
				if($valuestype=="0") {
					$content.=$obj->getWord1();
				}
				else {
					$content.=$obj->getWord3();
				}
				$content.='</span><input type="submit" onSubmit="this.disabled=true" /></span></span>';
			}

			if($this_right->getDelete())
			{
				$content.=' <span class="gui-btn"><span><a style="cursor: pointer" OnClick="if (confirm(\'�� �������, ��� ������ ��������� ������� ';
				if($valuestype==0)
				{
					$content.=$obj->getWord1();
				}
				elseif($valuestype==1)
				{
					$content.=$obj->getWord3();
				}
				$content.='?\')){ document.location=\''.$curdir.$kind.'/'.$obj->getName().'/'.$a["id"].'/action=dynamicaction&actiontype=delete&valuestype='.$valuestype.'\'}">������� ';
				if($valuestype==0)
				{
					$content.=$obj->getWord1();
				}
				elseif($valuestype==1)
				{
					$content.=$obj->getWord3();
				}
				$content.='</a></span></span>';
			}
            if(($this_right->getChange() || $this_right->getAdd()) && $this_right->getView()) {
				$content.='</center>
</form>';
			}
			elseif($this_right->getView()) {				$content.='</center>
';
			}
		}
		else
		{
			if($this_right->getView())
			{
				$valuestype=0;

				if($this_type==3)
				{
					$filds2=$obj->getElems2();
				}

				$content.='<center><div class="cb_editor"';
				if($obj->getSize()!='' && $obj->getSize()!=0)
				{
					$content.=' style="width: '.$obj->getSize().';"';
				}
				$content.='>
		<table cellpadding="0" cellspacing="0" border="0" width=100% align=center>
		<tr valign="bottom">
			<td>
			';
				if($this_right->getAdd())
				{
					$content.='<center><a href="'.$curdir.$kind.'/'.$obj->getName().'/act=add" class="ctrlink">[+] �������� '.$obj->getWord1().'</a></center>';
					if($this_type==3)
					{
						$content.='<center><a href="'.$curdir.$kind.'/'.$obj->getName().'/act=add&valuestype=1" class="ctrlink">[+] �������� '.$obj->getWord3().'</a></center>';
					}
					else {
						$content.='<br />';
					}
				}

				for($i=0;$i<count($this_sort[0]);$i++)
				{
					$this_type==3 && $order.=$this_sort[0][$i][0].' '.$this_sort[0][$i][1].', ';
					if($this_sort[0][$i][2])
					{
						$show[]=$this_sort[0][$i][0];
						$nam[]=$this_sort[0][$i][3];
						$spec[]=$this_sort[0][$i][4];
					}
				}
				$this_type==3 && $order=substr($order,0,strlen($order)-2);

				if($this_type==3)
				{
					$content.='
<ul class="ollist">
';
					for($i=0;$i<count($this_sort[1]);$i++)
					{
						$order2.=$this_sort[1][$i][0].' '.$this_sort[1][$i][1].', ';
						if($this_sort[1][$i][2])
						{
							$show2[]=$this_sort[1][$i][0];
							$nam2[]=$this_sort[1][$i][3];
							$spec2[]=$this_sort[1][$i][4];
						}
					}
					$order2=substr($order2,0,strlen($order2)-2);

					if($type3_foundparents!=' ')
					{
						$qq="(id IN (".substr($type3_foundids,0,strlen($type3_foundids)-2).") OR id IN (".substr($type3_foundparents,0,strlen($type3_foundparents)-2)."))";
					}
					else
					{
						$qq="id IN (".substr($type3_foundids,0,strlen($type3_foundids)-2).")";
					}
					$ok=make5fieldtree(true,$this_table,$obj->getParent(),0," AND ".$obj->getContent()."='{menu}' AND ".$qq, $obj->getCode()." asc LIMIT ".($page*$grads).", ".$grads,1,"id",$obj->getName2(),1000000);

					$ok7=make5field($this_table." WHERE ".$obj->getParent()."=0 AND ".$obj->getContent()."!='{menu}' ORDER by ".$order2,"id",$obj->getName2());

					$result=mysql_query("SELECT COUNT(id) FROM ".$this_table." WHERE ".$obj->getParent()."=0 AND ".$qq);
					$a = mysql_fetch_array($result);
					$pagetotal=$a[0];

					$levelnow=0;

					if($ok[1][0]!='' || $ok7[1][0]!='')
					{
						$content.='<li><b>������� �������</b>
				';
						for($j=1;$j<count($ok);$j++)
						{
							$result=mysql_query("SELECT * FROM ".$this_table." WHERE id=".$ok[$j][0]);
							$a = mysql_fetch_array($result);

							if($ok[$j][2]>$levelnow)
							{
								$content.='<ol class="ollist">
						';
								$levelnow=$ok[$j][2];
							}
							elseif($ok[$j][2]<$levelnow)
							{
								$close=$levelnow-$ok[$j][2];
								for($n=0;$n<$close;$n++)
								{
									$content.='
					</ol>
				';
								}
								$levelnow=$ok[$j][2];
							}
							if(stripos($type3_foundids,' '.$a["id"].',')!==false || stripos($type3_foundparents,' '.$a["id"].',')!==false)
							{
								$ss='';
								$content.='<li>';
								if(stripos($type3_foundids,' '.$a["id"].',')!==false)
								{
									$content.='<a href="'.$curdir.$kind.'/'.$obj->getName().'/'.$a["id"].'/act=view">';
								}

								for($i=0;$i<count($show);$i++)
								{
									if($i>0)
									{
										$ss.='. ';
									}

									foreach($filds as $f=>$v)
									{
										if($v->getName()==$show[$i])
										{
											if($nam[$i])
											{
												$ss.=$v->getSname().': ';
											}
											$ss.='<b>';
											if($a[$show[$i]]=='') {$ss.='<i>�� ����������</i>';}
											else {
												if($spec[$i]!='')
												{
													if($spec[$i][0]==1 || $spec[$i][0]==3)
													{
														$ss.=find5field($prefix.$spec[$i][1],$spec[$i][2],$a[$show[$i]],$spec[$i][3]);
													}
													elseif($spec[$i][0]==2)
													{
														for($d=0;$d<count($spec[$i][1]);$d++)
														{
															if($spec[$i][1][$d][0]==$a[$show[$i]])
															{
																$ss.=$spec[$i][1][$d][1];
																break;
															}
														}
													}
												}
												else
												{
													if($v->getType()=="checkbox")
													{
														if($a[$show[$i]]==1)
														{
															$ss.='<font color="green"><b>&#8730</b></font>';
														}
														else
														{
															$ss.='<font color="red"><b>X</b></font>';
														}
													}
													elseif($v->getType()=="calendar")
													{
														$ss.=date("d.m.Y",strtotime($a[$show[$i]]));
													}
													elseif($v->getType()=="timestamp")
													{
														$ss.=date("d.m.Y",$a[$show[$i]]).' � '.date("G:i",$a[$show[$i]]);
													}
													else
													{
														$ss.=decode2($a[$show[$i]]);
													}
												}
											}
											$ss.='</b>';
											break;
										}
									}
								}
								$content.=$ss.'.';
								if(stripos($type3_foundids,' '.$a["id"].',')!==false)
								{
									$content.='</a>';
								}
								$content.='
';
							}
							$ok2=make5field($this_table." WHERE ".$obj->getParent()."=".$ok[$j][0]." AND ".$obj->getContent()."!='{menu}' ORDER by ".$order2,"id",$obj->getName2());

							if($ok2[0][0]!='')
							{
								$content.='<ul class="ullist">';
								for($s=0;$s<count($ok2);$s++)
								{
									$result=mysql_query("SELECT * FROM ".$this_table." WHERE id=".$ok2[$s][0]);
									$a = mysql_fetch_array($result);

									if(stripos($type3_foundids,' '.$a["id"].',')!==false || stripos($type3_foundparents,' '.$a["id"].',')!==false)
									{
										$ss='';
										$content.='<li>';
										if(stripos($type3_foundids,' '.$a["id"].',')!==false)
										{
											$content.='<a href="'.$curdir.$kind.'/'.$obj->getName().'/'.$a["id"].'/act=view&valuestype=1">';
										}

										for($i=0;$i<count($show2);$i++)
										{
											if($i>0)
											{
												$ss.='; ';
											}

											foreach($filds2 as $f=>$v)
											{
												if($v->getName()==$show2[$i])
												{
													if($nam2[$i])
													{
														$ss.=$v->getSname().': ';
													}
													$ss.='<b>';
													if($a[$show2[$i]]=='')
													{
														if($show2[$i]==$obj->getName2() && ($a[$obj->getCode()]=='default' || $a[$obj->getCode()]=='1'))
														{
															$ss.='<i>�� ���������</i>';
														}
														else
														{
															$ss.='<i>�� ����������</i>';
														}
													}
													else {
														if($spec2[$i]!='')
														{
															if($spec2[$i][0]==1 || $spec2[$i][0]==3)
															{
																$ss.=find5field($prefix.$spec2[$i][1],$spec2[$i][2],$a[$show2[$i]],$spec2[$i][3]);
															}
															elseif($spec2[$i][0]==2)
															{
																for($d=0;$d<count($spec2[$i][1]);$d++)
																{
																	if($spec2[$i][1][$d][0]==$a[$show2[$i]])
																	{
																		$ss.=$spec2[$i][1][$d][1];
																		break;
																	}
																}
															}
														}
														else
														{
															if($v->getType()=="checkbox")
															{
																if($a[$show2[$i]]==1)
																{
																	$ss.='<font color="green"><b>&#8730</b></font>';
																}
																else
																{
																	$ss.='<font color="red"><b>X</b></font>';
																}
															}
															elseif($v->getType()=="calendar")
															{
																$ss.=date("d.m.Y",strtotime($a[$show2[$i]]));
															}
															elseif($v->getType()=="timestamp")
															{
																$ss.=date("d.m.Y",$a[$show2[$i]]).' � '.date("G:i",$a[$show2[$i]]);
															}
															else
															{
																$ss.=decode2($a[$show2[$i]]);
															}
														}
													}
													$ss.='</b>';
													break;
												}
											}
										}
										$content.=$ss.'.';
										if(stripos($type3_foundids,' '.$a["id"].',')!==false)
										{
											$content.='</a>';
										}
										$content.='
';
									}
								}
								$content.='
</ul>';
							}
						}
                        for($j=0;$j<count($ok7);$j++)
						{
							$result=mysql_query("SELECT * FROM ".$this_table." WHERE id=".$ok7[$j][0]);
							$a = mysql_fetch_array($result);

							if(stripos($type3_foundids,' '.$a["id"].',')!==false || stripos($type3_foundparents,' '.$a["id"].',')!==false)
							{
								$ss='';
								$content.='<li class="ullist">';
								if(stripos($type3_foundids,' '.$a["id"].',')!==false)
								{
									$content.='<a href="'.$curdir.$kind.'/'.$obj->getName().'/'.$a["id"].'/act=view&valuestype=1">';
								}

								for($i=0;$i<count($show2);$i++)
								{
									if($i>0)
									{
										$ss.='; ';
									}

									foreach($filds2 as $f=>$v)
									{
										if($v->getName()==$show2[$i])
										{
											if($nam2[$i])
											{
												$ss.=$v->getSname().': ';
											}
											$ss.='<b>';
											if($a[$show2[$i]]=='')
											{
												if($show2[$i]==$obj->getName2() && ($a[$obj->getCode()]=='default' || $a[$obj->getCode()]=='1'))
												{
													$ss.='<i>�� ���������</i>';
												}
												else
												{
													$ss.='<i>�� ����������</i>';
												}
											}
											else {
												if($spec2[$i]!='')
												{
													if($spec2[$i][0]==1 || $spec2[$i][0]==3)
													{
														$ss.=find5field($prefix.$spec2[$i][1],$spec2[$i][2],$a[$show2[$i]],$spec2[$i][3]);
													}
													elseif($spec2[$i][0]==2)
													{
														for($d=0;$d<count($spec2[$i][1]);$d++)
														{
															if($spec2[$i][1][$d][0]==$a[$show2[$i]])
															{
																$ss.=$spec2[$i][1][$d][1];
																break;
															}
														}
													}
												}
												else
												{
													if($v->getType()=="checkbox")
													{
														if($a[$show2[$i]]==1)
														{
															$ss.='<font color="green"><b>&#8730</b></font>';
														}
														else
														{
															$ss.='<font color="red"><b>X</b></font>';
														}
													}
													elseif($v->getType()=="calendar")
													{
														$content.=date("d.m.Y",strtotime($a[$show2[$i]]));
													}
													elseif($v->getType()=="timestamp")
													{
														$ss.=date("d.m.Y",$a[$show2[$i]]).' � '.date("G:i",$a[$show2[$i]]);
													}
													else
													{
														$ss.=decode2($a[$show2[$i]]);
													}
												}
											}
											$ss.='</b>';
											break;
										}
									}
								}
								$content.=$ss.'.';
								if(stripos($type3_foundids,' '.$a["id"].',')!==false)
								{
									$content.='</a>';
								}
								$content.='
';
							}
						}
					$content.='
</ul>';
					}
				$content.='
</ul>';
				}
				else
				{
					$result=mysql_query($query);

					$content.='<table class="menutable"><tr>';
					for($i=0;$i<count($this_sort[0]);$i++)
					{
						foreach($filds as $f=>$v)
						{
							if($v->getName()==$this_sort[0][$i][0] && $this_sort[0][$i][2])
							{
								if($sorting==($i*2+1))
								{
									$content.='<td class="menu"><a href="'.$curdir.$kind.'/'.$obj->getName().'/page='.$page.'&sorting='.($i*2+2).'" title="[������������� : '.strtolower($v->getSname()).' : �� ��������]" onMouseOver="document.getElementById(\'arrow\').src=\''.$server_absolute_path.$direct.'/down.gif\'" onMouseOut="document.getElementById(\'arrow\').src=\''.$server_absolute_path.$direct.'/up.gif\'">'.$v->getSname().'</a> <img src="'.$server_absolute_path.$direct.'/up.gif" id="arrow" /></td>';
								}
								elseif($sorting==($i*2+2))
								{
									$content.='<td class="menu"><a href="'.$curdir.$kind.'/'.$obj->getName().'/page='.$page.'&sorting='.($i*2+1).'" title="[������������� : '.strtolower($v->getSname()).' : �� �����������]" onMouseOver="document.getElementById(\'arrow\').src=\''.$server_absolute_path.$direct.'/up.gif\'" onMouseOut="document.getElementById(\'arrow\').src=\''.$server_absolute_path.$direct.'/down.gif\'">'.$v->getSname().'</a> <img src="'.$server_absolute_path.$direct.'/down.gif" id="arrow" /></td>';
								}
								else
								{
									$content.='<td class="menu"><a href="'.$curdir.$kind.'/'.$obj->getName().'/page='.$page.'&sorting='.($i*2+2).'" title="[������������� : '.strtolower($v->getSname()).' : �� ��������]">'.$v->getSname().'</a></td>';
								}
								break;
							}
						}
					}
					$content.='</tr>';
					$stringnum=1;
					while($a = mysql_fetch_array($result))
					{
						$content.='<tr';
						if($stringnum%2==1) {
							$content.=' class="string1"';
						}
						else {
							$content.=' class="string2"';
						}
						$content.='>';
						for($i=0;$i<count($show);$i++)
						{
							$content.='<td><a href="'.$curdir.$kind.'/'.$obj->getName().'/'.$a["id"].'/act=view">';
							foreach($filds as $f=>$v)
							{
								if($v->getName()==$show[$i])
								{
									if($a[$show[$i]]=='') {$content.='<i>�� ����������</i>';}
									else {
										if($spec[$i]!='')
										{
											if($spec[$i][0]==1 || $spec[$i][0]==3)
											{
												$content.=find5field($prefix.$spec[$i][1],$spec[$i][2],$a[$show[$i]],$spec[$i][3]);
											}
											elseif($spec[$i][0]==2)
											{
												for($d=0;$d<count($spec[$i][1]);$d++)
												{
													if($spec[$i][1][$d][0]==$a[$show[$i]])
													{
														$content.=$spec[$i][1][$d][1];
														break;
													}
												}
											}
										}
										else
										{
											if($v->getType()=="checkbox")
											{
												if($a[$show[$i]]==1)
												{
													$content.='<font color="green"><b>&#8730</b></font>';
												}
												else
												{
													$content.='<font color="red"><b>X</b></font>';
												}
											}
											elseif($v->getType()=="calendar")
											{
												$content.=date("d.m.Y",strtotime($a[$show[$i]]));
											}
											elseif($v->getType()=="timestamp")
											{
												$content.=date("d.m.Y",$a[$show[$i]]).' � '.date("G:i",$a[$show[$i]]);
											}
											else
											{
												$content.=decode2($a[$show[$i]]);
											}
										}
									}
									break;
								}
							}
							$content.='</a></td>';
						}
						$content.='</tr>';
						$stringnum++;
					}
					$content.='</table>';
				}

				$content.='
			</td>
		</tr>
		</table>';
			}
		}
	}

	if((($id!='' && !$stayhere && (($actiontype=="delete" && encode($_GET["ill"])=='') || $actiontype=="add" || ($actiontype=="change" && $trouble==false))) || ($id=='' && $act!="add")) || $this_type==1)
	{
		if($this_type!=3) {
			$content.='<br /><br />';
		}
		else {			$content.='<br />';
		}
		$content.='<center><table class="pagecount"><tr><td class="next">';
		if($page<($pagetotal/$grads)-1) {			$content.='<a href="'.$curdir.$kind.'/'.$obj->getName().'/page='.($page+1).'&sorting='.$sorting.'">';
		}
		$content.='&#8592; ���������';
		if($page<($pagetotal/$grads)-1) {
			$content.='</a>';
		}
		$content.='<br />';
		if($page!=ceil($pagetotal/$grads)-1 && $pagetotal>0) {
			$content.='<a href="'.$curdir.$kind.'/'.$obj->getName().'/page='.(ceil($pagetotal/$grads)-1).'&sorting='.$sorting.'" class="sm">';
		}
		else {			$content.='<span class="sm">';
		}
		$content.='���������';
		if($page!=ceil($pagetotal/$grads)-1) {
			$content.='</a>';
		}
		else {			$content.='</span>';
		}
		$content.='</td><td class="pagenums">';

		$totalobjects=$pagetotal;
		if($pagetotal==0) {
			$pagetotal=1;
		}
		$j=$page-5;
		if($j<1) {			$j=1;
		}
		$d=ceil($pagetotal/$grads);
		if($d>$j+12) {			$d=$j+12;
		}
		else {			$j=$d-12;
		}
		if($j<1) {
			$j=1;
		}
		for($i=$d;$i>=$j;$i--)
		{
			if($i-1!=$page) {
				$content.='<a href="'.$curdir.$kind.'/'.$obj->getName().'/page='.($i-1).'&sorting='.$sorting.'">'.$i.'</a>';
			}
			else {				$content.='<span class="selpage">'.$i.'</span>';
			}
		}
		$content.='<br />';
		$content.='<div class="pagegroup" onClick="document.location=\''.$curdir.$kind.'/'.$obj->getName().'/page=\'+calcPage(event,\'pagegroup_'.$obj->getName().'\','.ceil($pagetotal/$grads).')+\'&sorting='.$sorting.'\'" id="pagegroup_'.$obj->getName().'"><img src="'.$server_absolute_path.$direct.'/empty.gif" style="width: '.ceil(100/(ceil($pagetotal/$grads))).'%;" onClick="calcPageChild(event);" id="pagegroupscroll_'.$obj->getName().'" /></div>';

		$onloadfunc.='setScroll(\'pagegroupscroll_'.$obj->getName().'\',\'pagegroup_'.$obj->getName().'\','.$page.','.(ceil($pagetotal/$grads)-1).');';

		$content.='<span class="sm">(�� ������ � �� '.$grads.' ������� �� '.$totalobjects.')</span></td>';
		$content.='<td class="previous">';
		if(ceil($totalobjects/$grads)-1>0 && $page>0) {
			$content.='<a href="'.$curdir.$kind.'/'.$obj->getName().'/page='.($page-1).'&sorting='.$sorting.'">';
		}
		$content.='���������� &#8594;';
		if($page<($pagetotal/$grads)-1) {
			$content.='</a>';
		}
		$content.='<br />';
		if($page!=0 && ceil($pagetotal/$grads)-1>0) {
			$content.='<a href="'.$curdir.$kind.'/'.$obj->getName().'/sorting='.$sorting.'" class="sm">';
		}
		else {
			$content.='<span class="sm">';
		}
		$content.='������';
		if($page!=0 && ceil($pagetotal/$grads)-1>0) {
			$content.='</a>';
		}
		else {
			$content.='</span>';
		}
		$content.='</td></tr></table></center>';
	}

	return($content);
}
?>