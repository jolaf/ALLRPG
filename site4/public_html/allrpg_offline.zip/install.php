<?php
include_once("dbinc.php");

$link = mysql_connect($dbhost,$dbuser,$dbpass);

mysql_query("CREATE DATABASE IF NOT EXISTS ".$dbname);

mysql_query("USE ".$dbname);

mysql_query("SET NAMES cp1251");

mysql_query("CREATE TABLE IF NOT EXISTS `".$prefix."users` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `fio` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `rights` varchar(255) NOT NULL,
  `site_id` int(11) NOT NULL,
  `date` INT NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `site_id` (`site_id`)
) AUTO_INCREMENT=2 ;");

$rpass=md5(encode($rpass));

mysql_query("INSERT INTO `".$prefix."users` VALUES (1, '���� �.�.�.', '".$ruser."', '".$rpass."', '-10000-', 0, '".time()."');");

mysql_query("CREATE TABLE IF NOT EXISTS `".$prefix."sites` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `allrpg_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `sorter` int(11) NOT NULL,
  `sorter2` int(11) NOT NULL,
  `money` varchar(255) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;");

mysql_query("CREATE TABLE IF NOT EXISTS `".$prefix."roles` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `allrpg_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `player` varchar(255) NOT NULL,
  `playerprofile` varchar(255) NOT NULL,
  `gender` int(11) NOT NULL,
  `em` varchar(255) NOT NULL,
  `em2` varchar(255) NOT NULL,
  `phone2` varchar(255) NOT NULL,
  `icq` varchar(255) NOT NULL,
  `skype` varchar(255) NOT NULL,
  `jabber` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `birth` date NOT NULL,
  `city` varchar(255) NOT NULL,
  `sickness` text NOT NULL,
  `player_changed` enum('0','1') NOT NULL,
  `team` tinyint(4) NOT NULL,
  `vacancy` int(11) NOT NULL,
  `money` varchar(255) NOT NULL,
  `moneydone` enum('0','1') NOT NULL,
  `sorter` varchar(255) NOT NULL,
  `locat` int(11) NOT NULL,
  `allinfo` longtext NOT NULL,
  `status` int(11) NOT NULL,
  `changed` int(11) NOT NULL,
  `todelete` tinyint(4) NOT NULL,
  `todelete2` tinyint(4) NOT NULL,
  `alltold` enum('0','1') NOT NULL,
  `roleteamkolvo` int(11) NOT NULL,
  `datesent` varchar(255) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `site_id` (`site_id`),
  KEY `sorter` (`sorter`),
  KEY `locat` (`locat`),
  KEY `status` (`status`),
  KEY `changed` (`changed`),
  KEY `team` (`team`),
  KEY `player` (`player`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;");

mysql_query("CREATE TABLE IF NOT EXISTS `".$prefix."rolescomments` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `allrpg_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `type` int(11) NOT NULL,
  `content` text NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `role_id` (`role_id`),
  KEY `type` (`type`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");

mysql_query("CREATE TABLE IF NOT EXISTS `".$prefix."rolescommentsread` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `role_id` (`role_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");

mysql_query("CREATE TABLE IF NOT EXISTS `".$prefix."rolefields` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `allrpg_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `rolename` varchar(255) NOT NULL,
  `roletype` varchar(255) NOT NULL,
  `rolemustbe` enum('0','1') NOT NULL,
  `roledefault` text NOT NULL,
  `rolerights` int(11) NOT NULL,
  `rolehelp` text NOT NULL,
  `rolevalues` text NOT NULL,
  `rolecode` int(11) NOT NULL,
  `rolewidth` int(11) NOT NULL,
  `roleheight` int(11) NOT NULL,
  `filter` enum('0','1') NOT NULL default '0',
  `team` enum('0','1') NOT NULL default '0',
  `date` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `site_id` (`site_id`),
  KEY `team` (`team`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;");

mysql_query("CREATE TABLE IF NOT EXISTS `".$prefix."roleshistory` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `role_id` int(11) NOT NULL,
  `initiator_id` int(11) NOT NULL,
  `allinfo` longtext NOT NULL,
  `vacancy` int(11) NOT NULL,
  `money` varchar(255) NOT NULL,
  `moneydone` enum('0','1') NOT NULL,
  `locat` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `todelete` tinyint(4) NOT NULL,
  `alltold` enum('0','1') NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `role_id` (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;");

mysql_query("CREATE TABLE IF NOT EXISTS `".$prefix."roleslocat` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `allrpg_id` int(11) NOT NULL,
  `parent` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` int(11) NOT NULL default '100',
  `content` varchar(255) NOT NULL default '{menu}',
  `description` text NOT NULL,
  `site_id` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `site_id` (`site_id`),
  KEY `code` (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;");


mysql_query("CREATE TABLE IF NOT EXISTS `".$prefix."rolevacancy` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `allrpg_id` int(11) NOT NULL,
  `locat` int(11) NOT NULL,
  `team` enum('0','1') NOT NULL default '0',
  `name` varchar(255) NOT NULL,
  `code` int(11) NOT NULL default '100',
  `kolvo` int(11) NOT NULL,
  `teamkolvo` int(11) NOT NULL,
  `maybetaken` text NOT NULL,
  `taken` text NOT NULL,
  `content` text NOT NULL,
  `site_id` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `site_id` (`site_id`),
  KEY `team` (`team`),
  KEY `locat` (`locat`),
  KEY `code` (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;");

mysql_query("CREATE TABLE IF NOT EXISTS `".$prefix."roleslinks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `allrpg_id` int(11) NOT NULL,
  `parent` int(11) NOT NULL,
  `descr` text NOT NULL,
  `site_id` int(11) NOT NULL,
  `vacancies` text NOT NULL,
  `hideother` enum('0','1') NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` int(11) NOT NULL,
  `content` text NOT NULL,
  `roles` text NOT NULL,
  `roles2` text NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`),
  KEY `parent` (`parent`),
  FULLTEXT KEY `vacancies` (`vacancies`),
  FULLTEXT KEY `roles` (`roles`),
  FULLTEXT KEY `roles2` (`roles2`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");

print('<html>
<head>
<title>allrpg.info: ����������� offline-������</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<meta http-equiv="author" content="����">
<link rel="stylesheet" href="main.css" rev="contents" type="text/css">
</head>

<body>
Offline-������ ������� ���������� �������� allrpg.info ������� �����������. �� �������� ������� ���� install.php.
</body>
</html>');

mysql_close($link);
?>