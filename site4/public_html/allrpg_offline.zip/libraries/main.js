function checknum(that){
	if(that.value=="")
	{
		that.value="0";
	}
	else
	{
		t=parseFloat(that.value);
		if (isNaN(t))
		{
			alert("� ������ ���� ����� ������� ������ �����!");
			that.value="0";
		}
		else
		{
			if(t<0)
			{
				t=t+(t*2*-1);
			};
			that.value=t;
		}
	}
}

function openbig(path,width,height,wnd)
{
	window.open(path,wnd,"toolbar=no,location=no,directories=no,status=no,menubar=no,resize=no,scrollbars=yes,width="+width+",height="+height);
}

function textCounter(field, maxlimit) {
	if (field.value.length > maxlimit)
	{
		field.value = field.value.substring(0, maxlimit);
		alert("� ������ ���� �� ����� ���� ����� "+maxlimit+" ��������.");
	}
}

function checkMultis(field, input, text, textout) {
	text+="<br>";
	textout+="<br>";
	if(document.getElementById(field).innerHTML=='� ������� �')
	{
		document.getElementById(field).innerHTML='';
	}
	if(document.getElementById(input).checked)
	{
		document.getElementById(field).innerHTML+=text;
	}
	else
	{
		var re = new RegExp(textout, 'i');
		document.getElementById(field).innerHTML=document.getElementById(field).innerHTML.replace(re,'');
	}
	if(document.getElementById(field).innerHTML=='')
	{
		document.getElementById(field).innerHTML='� ������� �';
	}
}

function checkMultisOne(field, input, text) {
	if(document.getElementById(field).innerHTML=='� ������� �')
	{
		document.getElementById(field).innerHTML='';
	}
	if(document.getElementById(input).checked)
	{
		document.getElementById(field).innerHTML=text;
	}
	if(document.getElementById(field).innerHTML=='')
	{
		document.getElementById(field).innerHTML='� ������� �';
	}
}

var _dialogPromptID=null;
var _blackoutPromptID=null;

function IEprompt(innertxt,def) {

   that=this;   // A workaround to javascript's oop idiosyncracies.

   this.wrapupPrompt = function (cancled) {
		val=document.getElementById('iepromptfield').value;
        // clear out the dialog box
        _dialogPromptID.style.display='none';
        // clear out the screen
        _blackoutPromptID.style.display='none';
        // clear out the text field
        document.getElementById('iepromptfield').value = '';
        // if the cancel button was pushed, force value to null.
        if (cancled) { val = '' }
        // call the user's function
        promptCallback(val);
    	return false;
	}

	//if def wasn't actually passed, initialize it to null
	if (def==undefined) { def=''; }

	if (_dialogPromptID==null) {
         // Check to see if we've created the dialog divisions.
         // This block sets up the divisons
         // Get the body tag in the dom
         var tbody = document.getElementsByTagName("body")[0];
         // create a new division
         tnode = document.createElement('div');
         // name it
         tnode.id='IEPromptBox';
         // attach the new division to the body tag
         tbody.appendChild(tnode);
         // and save the element reference in a global variable
         _dialogPromptID=document.getElementById('IEPromptBox');
         // Create a new division (blackout)
         tnode = document.createElement('div');
         // name it.
         tnode.id='promptBlackout';
         // attach it to body.
         tbody.appendChild(tnode);
         // And get the element reference
         _blackoutPromptID=document.getElementById('promptBlackout');
         // assign the styles to the blackout division.
         _blackoutPromptID.style.opacity='.9';
         _blackoutPromptID.style.position='absolute';
         _blackoutPromptID.style.top='0px';
         _blackoutPromptID.style.left='0px';
         _blackoutPromptID.style.backgroundColor='#555555';
         _blackoutPromptID.style.filter='alpha(opacity=90)';
         _blackoutPromptID.style.height='100%';
         _blackoutPromptID.style.display='block';
         _blackoutPromptID.style.zIndex='200';
         // assign the styles to the dialog box
         _dialogPromptID.style.position='absolute';
         _dialogPromptID.style.width='330px';
         _dialogPromptID.style.zIndex='201';
      }
      // This is the HTML which makes up the dialog box, it will be inserted into
      // innerHTML later. We insert into a temporary variable because
      // it's very, very slow doing multiple innerHTML injections, it's much
      // more efficient to use a variable and then do one LARGE injection.
      var tmp = '<div class="ieprompt">'+innertxt + '<br><br>';
      tmp += '<form action="" onsubmit="return that.wrapupPrompt()">';
      tmp += '<input id="iepromptfield" name="iepromptdata" type=text class="inputtext" value="'+def+'">';
      tmp += '<br><br><center>';
      tmp += '<span class="gui-btn"><span><span>OK</span><input type="submit" /></span></span>';
      tmp += '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
      tmp += '<span class="gui-btn"><span><a style="cursor: pointer" onClick="that.wrapupPrompt(true)">������</a></span></span>';
      tmp += '</form></div>';
      // Stretch the blackout division to fill the entire document
      // and make it visible.  Because it has a high z-index it should
      // make all other elements on the page unclickable.
      _blackoutPromptID.style.height='100%';
      _blackoutPromptID.style.width='100%';
      _blackoutPromptID.style.display='block';
      // Insert the tmp HTML string into the dialog box.
      // Then position the dialog box on the screen and make it visible.
      _dialogPromptID.innerHTML=tmp;
      _dialogPromptID.style.top=parseInt(document.documentElement.scrollTop+(screen.height/3))+'px';
      _dialogPromptID.style.left=parseInt((document.body.offsetWidth-315)/2)+'px';
      _dialogPromptID.style.display='block';
      // Give the dialog box's input field the focus.
      document.getElementById('iepromptfield').focus();
}

function getXOffset(e) {
	e = (e) ? e : window.event;
	if (typeof e.offsetX != 'undefined')
		return e.offsetX;
	else if(typeof e.pageX == "number") {
		var Element = e.target;
		var CalculatedTotalOffsetLeft = 0;
		while (Element.offsetParent)
		{
			CalculatedTotalOffsetLeft += Element.offsetLeft ;
			Element = Element.offsetParent ;
		};
		return e.pageX - CalculatedTotalOffsetLeft;
	}
	else if (typeof e.pageX != 'undefined')
		return e.pageX - e.target.offsetLeft;
}

function getYOffset(e) {
	e = (e) ? e : window.event;
	if (typeof e.offsetY != 'undefined')
		return e.offsetY;
	else if(typeof e.pageY == "number") {
		var Element = e.target;
		var CalculatedTotalOffsetTop = 0;
		while (Element.offsetParent)
		{
			CalculatedTotalOffsetTop += Element.offsetTop ;
			Element = Element.offsetParent ;
		};
		return e.pageY - CalculatedTotalOffsetTop;
	}
	else if (typeof e.pageY != 'undefined')
		return e.pageY - e.target.offsetTop;
}

function getObjWidth(e) {
	return document.getElementById(e).offsetWidth;
}

function calcPageChild(e) {	e.cancelBubble=true;
	if(e.stopPropagation)
		e.stopPropagation();
}

function calcPage(e,Elem,pages) {	page=(getXOffset(e)+1)/getObjWidth(Elem);
	return Math.floor(pages-(pages/100*(page*100)));
}

function setScroll(e,e2,page,pages) {    sw=getObjWidth(e);
    ew=getObjWidth(e2);
    posbegin=(ew/-2)+(sw/2);
    posend=(ew/2)-(sw/2);
    widt=posend-posbegin;
    if(pages>0) {
    	step=widt/pages;
    }
    else {    	step=0;
    }
    pos=Math.round(posbegin+(step*(pages-page)));
    document.getElementById(e).style.left=pos+"px";
}

var onobject=Array();
var optimer=Array();
var outtimer=Array();

function setOpacity(el,inout) {
	if(optimer[el]!=null) {
		clearTimeout(optimer[el]);
	}
	element=document.getElementById(el);
	level=element.style.opacity;
	if(level == null) {
		oAlpha = element.filters['DXImageTransform.Microsoft.alpha'] || element.filters.alpha;
		if (oAlpha) level=oAlpha.opacity/100;
			else level=0;
	}
	//if(inout=="in") {
	//	element.style.display="block";
	//}
	level=Math.round(level*100);
	if(inout=="in") {
		level+=5;
	}
	else {		level-=5;
	}
	element.style.opacity = level/100;
	element.style.MozOpacity = level/100;
	element.style.KhtmlOpacity = level/100;

	if (document.body.filters && navigator.appVersion.match(/MSIE ([\d.]+);/)[1]>=5.5) {
		element.style.filter = "progid:DXImageTransform.Microsoft.Alpha(opacity="+level+")";
	}
	if(inout=="out" && level<=0) {
		element.style.display="none";
	}
	else if(inout=="in" && level<=100 && onobject[el]) {
		optimer[el]=setTimeout("setOpacity('" + el + "', 'in')");
	}
	else if(inout=="out" && level>=0 && !onobject[el]) {
		optimer[el]=setTimeout("setOpacity('" + el + "', 'out')");
	}
}

function fadeIn(element){
	onobject[element]=true;
	clearTimeout(optimer[element]);
	clearTimeout(outtimer[element]);
	document.getElementById(element).style.display="block";
	setOpacity(element,'in');
}

function fadeOut(element) {
	onobject[element]=false;
	outtimer[element]=setTimeout("realfadeOut('" + element + "')", 100);
}

function realfadeOut(element) {
	if(!onobject[element]) {
		clearTimeout(optimer[element]);
		setOpacity(element,'out');
	}
}

// �������������� ������� ��������
var trans = [];
for (var i = 0x410; i <= 0x44F; i++)
  trans[i] = i - 0x350; // �-��-�
trans[0x401] = 0xA8;    // �
trans[0x451] = 0xB8;    // �

// ��������� ����������� ������� escape()
var escapeOrig = window.escape;

// �������������� ������� escape()
window.escape = function(str)
{
  var ret = [];
  // ���������� ������ ����� ��������, ������� ��������� ���������
  for (var i = 0; i < str.length; i++)
  {
    var n = str.charCodeAt(i);
    if (typeof trans[n] != 'undefined')
      n = trans[n];
    if (n <= 0xFF)
      ret.push(n);
  }
  return escapeOrig(String.fromCharCode.apply(null, ret));
}

function searchhelp(value,file,e) {	dont=false;
	if(document.getElementById("qwerty_helper").style.display=="none") {
		document.getElementById("qwerty_helper").style.display="block";
		dont=true;
	}
	if(value.length<3) {		document.getElementById("qwerty_helper").innerHTML="������� 3+ ����� ��� ���������";
	}
	else {
		e = (e) ? e : window.event;
		if(e.keyCode==40) {			if(dont==false) {
				obj = document.getElementById("qwerty_helper");
				s = obj.getElementsByTagName('a');
				j=-1;
				for(i=0;i<s.length;i++){
					if(s[i].className == "selected") {						s[i].className = "";
						j=i+1;
						if(j==s.length) {							j=-1;
						}
					}
				}
				if(j == -1) {					j=0;
				}
				if( document.createEvent ) {
					evObj = document.createEvent('MouseEvents');
					evObj.initEvent( 'mouseover', true, false );
					s[j].dispatchEvent(evObj);
				}
				else if( document.createEventObject ) {
					s[j].fireEvent('onmouseover');
				}
			}
		}
		else if(e.keyCode==38) {
            if(dont==false) {
	            obj = document.getElementById("qwerty_helper");
				s = obj.getElementsByTagName('a');
				j=s.length-1;
				for(i=j;i>=0;i--){
					if(s[i].className == "selected") {
						s[i].className = "";
						j=i-1;
						if(j==-1) {
							j=s.length-1;
						}
					}
				}
				if( document.createEvent ) {
					evObj = document.createEvent('MouseEvents');
					evObj.initEvent( 'mouseover', true, false );
					s[j].dispatchEvent(evObj);
				}
				else if( document.createEventObject ) {
					s[j].fireEvent('onmouseover');
				}
			}
		}
		else if(e.keyCode==27) {
			searchhide();
		}
		else if(e.keyCode==8 || e.keyCode==16 || e.keyCode==17 || e.keyCode==18 || e.keyCode==20 || e.keyCode==37 || e.keyCode==39 || e.keyCode==45 || e.keyCode==46) {}
		else {
			var xmlhttp =  new XMLHttpRequest();
			xmlhttp.open('POST', file, true);

			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4) {
					if (xmlhttp.status == 200) {
						i=0;
						var browser=navigator.appName;
						if(browser!="Microsoft Internet Explorer") {
							xmlhttp.responseXML.normalize();
						}
						var total = xmlhttp.responseXML.getElementsByTagName('total')[0].firstChild.data;
	                    var req = xmlhttp.responseXML.getElementsByTagName('req')[0].firstChild.data;
	                    content='';

						if(req==document.getElementById('qwerty').value) {							if(total>10) {
								content+='<div style="text-align: center; font-weight: bold;">�������� �� ��� ����������<br>�������� ������</div><br>';
							}

							if(total==0) {								content+='<b>��� ����������</b>';
							}
							else {
								if(total>10) {									total=10;
								}
								for(i=0;i<total;i++) {									content+='<a onClick="makesearch(\'' + xmlhttp.responseXML.getElementsByTagName('first')[i].firstChild.data + '\',true,this); document.getElementById(\'qwerty_form\').submit();" onMouseOver="makesearch(\'' + xmlhttp.responseXML.getElementsByTagName('first')[i].firstChild.data + '\',false,this)">' + xmlhttp.responseXML.getElementsByTagName('first')[i].firstChild.data + "</a>";
								}
							}

		 					document.getElementById("qwerty_helper").innerHTML=content;
		 				}
					}
				}
			}
			document.getElementById("qwerty_helper").innerHTML='���� �����...';

			xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded;');
			xmlhttp.send('value='+escape(value));
		}
    }
}

function searchhide() {	document.getElementById("qwerty_helper").style.display="none";
}

function makesearch(value,close,objer) {
	value=value.replace('<b>','');
	value=value.replace('</b>','');
	document.getElementById("qwerty").value=value;
	if(close) {
		objer.className="selected";
		searchhide();
	}
	else {		obj = document.getElementById("qwerty_helper");
		s = obj.getElementsByTagName('a');
		for(i=0;i<s.length;i++){
			if(s[i].className == "selected") {
				s[i].className = "";
			}
		}
		objer.className="selected";
	}
}