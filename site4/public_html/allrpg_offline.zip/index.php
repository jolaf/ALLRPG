<?php
$globaltimer=microtime(true);

require_once("dbinc.php");

start_mysql();
# ������������ ���������� � MySQL-��������

session_start();

if($action=="remind") {	unset($_SESSION["site_id"]);
	err_red("� ��� ��� ���� ������� � ������� �������.");
}
else {
	if($site>0) {		$_SESSION["site_id"]=$site;
	}
	if($site=="exit") {		unset($_SESSION["site_id"]);
	}
}

if($_SESSION["site_id"]!='' && $kind!='') {
	auth($prefix."users");
	# �����������

	require_once("kind_list.php");

	// ����������� ���������� ��������, ����� (hidden, timestamp, h1) � ����
	require_once($server_inner_path.$direct."/classes/classes_objects.php");
	require_once($server_inner_path.$direct."/classes/classes_rights.php");

	require_once("kind_".$kind.".php");
}
else {	require_once("kind_start.php");
}
if($content2=='') {
	echo("<html><body><script>document.location='".$server_absolute_path."error404.php';</script></body></html>");
	exit;
}

$content='<html>
<head>
<base href="'.$server_absolute_path.'">
<title>allrpg.offline 1.0</title>
<meta content="text/html; charset=windows-1251" http-equiv=Content-Type>
<link rel="stylesheet" type="text/css" href="main.css">
<link rel="stylesheet" type="text/css" href="'.$server_absolute_path.$direct.'/btn.css">
<link rel="stylesheet" type="text/css" href="'.$server_absolute_path.$direct.'/color/color.css">
<link rel="stylesheet" type="text/css" href="'.$server_absolute_path.$direct.'/calendar/theme.css">
<script type="text/javascript" src="'.$server_absolute_path.$direct.'/main.js"></script>
<script type="text/javascript" src="'.$server_absolute_path.$direct.'/sarissa/sarissa.js"></script>
<script type="text/javascript" src="'.$server_absolute_path.$direct.'/calendar/calendar_stripped.js"></script>
<script type="text/javascript" src="'.$server_absolute_path.$direct.'/calendar/calendar-ru_win_.js"></script>
<script type="text/javascript" src="'.$server_absolute_path.$direct.'/calendar/calendar-setup_stripped.js"></script>
</head>

<body>
<a name="top"></a>
<div class="topmenu">
<!--menu-->
</div><br>
<!--error-->
<!--maincontent-->';

for($i=0;$i<count($kinds);$i++)
{
	if($kinds[$i][0]=='hr')
	{
		if($theright[$kinds[$i][0]])
		{
			$menu.='
<hr>
';
			$seen=false;
		}
	}
	elseif($theright[$kinds[$i][0]])
	{
		if($seen)
		{
			$menu.=' | ';
		}
		if($kinds[$i][0]!=$kind)
		{
			$menu.='<a href="'.$server_absolute_path.$kinds[$i][0].'/">'.$kinds[$i][1].'</a>';
		}
		else
		{
			$menu.='<a href="'.$server_absolute_path.$kinds[$i][0].'/" class="selected">'.$kinds[$i][1].'</a>';
		}
		$seen=true;
	}
}

$content.='
</body>
</html>';

$maincontentchange="<!--maincontent-->";
$content=substr($content,0,strpos($content,$maincontentchange)).$content2.substr($content,strpos($content,$maincontentchange)+strlen($maincontentchange),strlen($content));
$menuchange="<!--menu-->";
$content=substr($content,0,strpos($content,$menuchange)).$menu.substr($content,strpos($content,$menuchange)+strlen($menuchange),strlen($content));

$errorchange="<!--error-->";
$content=substr($content,0,strpos($content,$errorchange)).$error.substr($content,strpos($content,$errorchange)+strlen($errorchange),strlen($content));

print($content);
# ����� ��������� ���������� ��������

stop_mysql();
# ������ ���������� � MySQL-��������

$globaltimer=microtime(true)-$globaltimer;
echo('
<!-- execution time: '.$globaltimer.'s-->');
?>