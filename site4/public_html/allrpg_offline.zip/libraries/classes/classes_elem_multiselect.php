<?php

class netMultiselect extends netBaseElem {
	var $values; //������ ������, �� ������� ��������� id � �������� checkbox'��
	var $one; //�������������� (radio) �� ����� ������� (true|false)
	var $images; //������ ������, �� ������� ��������� �������� ��� ��������������� checkbox'��
	var $path; //���� �� ����� �������� $images
	var $locked; //��������������� � ��������� checkbox'�

	function setVal($a,$post,$linenum) {
		$value='-';
		$name=$this->getName();
		if($post)
		{
			if($this->getOne())
			{
				if(isset($linenum)) {
					$value.=$_POST[$name][$linenum].'-';
				}
				else
				{
					$value.=$_POST[$name].'-';
				}
			}
			else
			{
				$values=$this->getValues();
				for($t=0;$t<count($values);$t++)
				{
					if(isset($linenum) && $_POST[$name][$values[$t][0]][$linenum]=="on") {
						$value.=$values[$t][0].'-';
					}
					elseif($_POST[$name][$values[$t][0]]=="on") {
						$value.=$values[$t][0].'-';
					}
				}
			}
		}
		elseif($a[$name]!='') {
			$value=decode($a[$name]);
		}
		$this->setValue($value);
	}

	function setValues($values) {
		$this->values=$values;
	}

	function setOne($one) {
		$this->one=$one;
	}

	function setImages($images) {
		$this->images=$images;
	}

	function setPath($path) {
		$this->path=$path;
	}

	function setLocked($locked) {
		$this->locked=$locked;
	}

	function getValues() {
		return ($this->values);
	}

	function getOne() {
		return ($this->one);
	}

	function getImages() {
		return ($this->images);
	}

	function getPath() {
		return ($this->path);
	}

	function getLocked() {
		return ($this->locked);
	}

	function netMultiselect($params) {
		$this->netBaseElem($params);
		$this->setValues($params["values"]);
		$this->setOne($params["one"]);
		$this->setImages($params["images"]);
		$this->setPath($params["path"]);
		$this->setLocked($params["locked"]);
	}

	function draw($type, $can, $linenum) {
		if($can=="write")
		{
			$content.=$this->trueDraw($linenum);
		}
		else
		{
			$values=$this->getValues();
			$val=$this->getVal();

			$images=$this->getImages();
   			$linkatend=$this->getLinkAtEnd();

			for($t=0;$t<count($values);$t++)
			{
				if(stripos($val,'-'.$values[$t][0].'-')!==false)
				{
					$linkatbegin=$this->getLinkAtBegin();
					if(stripos($linkatbegin,'{value}')!==false) {
                		$linkatbegin=str_ireplace('{value}',$values[$t][0],$linkatbegin);
   					}
					$content.=$linkatbegin;
					if($images!='') {
						$content.='<img src="'.$this->getPath().$images[$t][1].'" border="0" />'.$linkatend.' '.$linkatbegin;
					}
					$content.=$values[$t][1].$linkatend;
					if($this->getOne()==false)
					{
						$content.='<br />
';
					}
				}
			}
		}
		return($content);
	}

	function trueDraw($linenum) {
		$value=$this->getVal();
		$name=$this->getName();

		$massiv=$this->getValues();
		$images=$this->getImages();
		$locked=$this->getLocked();
		$width=$this->getWidth();
		if($width!='' && stripos($width,'%')===false && stripos($width,'px')===false) {
			$width.='px';
		}
		$height=$this->getHeight();
		if($height!='' && stripos($height,'%')===false && stripos($height,'px')===false) {
			$height.='px';
		}

		if(isset($linenum))
		{
			$linenum+=0;
			$linenum='[line'.$linenum.']';
		}
		else
		{
			$linenum='';
		}

		$content.='<div class="dropfield" ';
		if($width!='') {			$content.='style="width: '.$width.'" ';
		}
		$content.='id="selected_'.$name.$linenum.'" onClick="document.getElementById(\''.$name.$linenum.'\').style.width=(getObjWidth(\'selected_'.$name.$linenum.'\'))+\'px\'; document.getElementById(\'main_'.$name.$linenum.'\').style.width=(getObjWidth(\'selected_'.$name.$linenum.'\')-28)+\'px\'; document.getElementById(\''.$name.$linenum.'\').style.display=\'block\';">';
		if($value!='' && $value!='-' && $value!='--')
		{
			for($i=0;$i<count($massiv);$i++)
			{
				if(strpos($value,"-".$massiv[$i][0]."-")!==false)
				{
					$content.=str_replace('"','\'',$massiv[$i][1]).'<br />';
				}
			}
		}
		else
		{
			$content.='� ������� �';
		}
		$content.='</div>';
		$content.='<div class="dropfield2" id="'.$name.$linenum.'">
<div class="main" id="main_'.$name.$linenum.'"';
        if($height!='') {
        	$content.=' style="height: '.$height.'"';
        }
		$content.='>';

		if($this->getOne() && !$this->getMustBe()) {   			$content.='<input type="radio" name="'.$name.$linenum.'" id="'.$name.'[0]'.$linenum.'" value="" class="radio"';
   			if(stripos($value,'-0-')!==false) {
				$content.=' checked';
			}
			$content.=' OnClick="checkMultisOne(\'selected_'.$name.$linenum.'\',\''.$name.'[0]'.$linenum.'\',\'\'); document.getElementById(\''.$name.$linenum.'\').style.display=\'none\';"';
			$content.='><label for="'.$name.'[0]'.$linenum.'"> �� ��������</label><br>';
		}

		for($i=0;$i<count($massiv);$i++)
		{
			if($this->getOne())
			{
				$content.='<input type="radio" name="'.$name.$linenum.'" id="'.$name.'['.$massiv[$i][0].']'.$linenum.'" value="'.$massiv[$i][0].'" class="radio"';
			}
			else
			{
				$content.='<input type="checkbox" name="'.$name.'['.$massiv[$i][0].']'.$linenum.'" id="'.$name.'['.$massiv[$i][0].']'.$linenum.'" class="checkbox"';
			}

			if(stripos($value,'-'.$massiv[$i][0].'-')!==false)
			{
				$content.=' checked';
			}

			if(stripos($locked,'-'.$massiv[$i][0].'-')!==false)
			{
				$content.=' OnClick="return false;"';
			}

			$massivelem1=str_ireplace('"','\\\'',$massiv[$i][1]);
			$massivelem2=str_ireplace('"','\\\'',$massiv[$i][1]);
			$massivelem2=str_ireplace('\(','\\\(',$massivelem2);
			$massivelem2=str_ireplace(')','\\\)',$massivelem2);
			if($this->getOne())
			{
				$content.=' OnClick="checkMultisOne(\'selected_'.$name.$linenum.'\',\''.$name.'['.$massiv[$i][0].']'.$linenum.'\',\''.$massivelem1.'\'); document.getElementById(\''.$name.$linenum.'\').style.display=\'none\';"';
			}
			else
			{
				$content.=' OnClick="checkMultis(\'selected_'.$name.$linenum.'\',\''.$name.'['.$massiv[$i][0].']'.$linenum.'\',\''.$massivelem1.'\',\''.$massivelem2.'\')"';
			}

			$content.='><label for="'.$name.'['.$massiv[$i][0].']'.$linenum.'"> ';
			if($images!='')
			{
				$content.='<img src="'.$this->getPath().$images[$i][1].'" /> ';
			}
			$content.=$massiv[$i][1].'</label><br>';
		}
		$content.='</div><div class="clean"><a onClick="document.getElementById(\''.$name.$linenum.'\').style.display=\'none\';" class="cross">X</a></div></div>';

		return($content);
	}

	function destroy() {
		unset($this);
	}
}

?>