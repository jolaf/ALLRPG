<?php

class netCalendar extends netBaseElem {
	function setVal($a,$post,$linenum) {
		$value='';
		$name=$this->getName();
		if($post)
		{
			if(isset($linenum)) {
				$value=$_POST[$name][$linenum];
			}
			else
			{
				$value=$_POST[$name];
			}
		}
		elseif($a[$name]!='') {
			$value=decode($a[$name]);
		}
		$this->setValue($value);
	}

	function netCalendar($params) {
		$this->netBaseElem($params);
		if($params["default"]=='')
		{
			$this->setDefault(date("Y-m-d"));
		}
	}

	function draw($type, $can, $linenum) {
		if($can=="write") {
			$content.=$this->trueDraw($linenum);
		}
		else
		{
			$linkatbegin=$this->getLinkAtBegin();
			$linkatend=$this->getLinkAtEnd();
			$content.=$linkatbegin.date("d.m.Y",strtotime($this->getVal())).$linkatend;
		}
		return($content);
	}

	function trueDraw($linenum) {
		$GLOBALS["js"]['calendar']=true;
		$value=$this->getVal();
		$name=$this->getName();

		if(isset($linenum))
		{
			$linenum+=0;
			$linenum='['.$linenum.']';
		}
		else
		{
			$linenum='';
		}

		$value2=date("d.m.Y", strtotime($value));
		$content.='<nobr><input type="hidden" name="'.$name.$linenum.'" id="f_'.$name.$linenum.'" value="'.$value.'" /> <span id="e_'.$name.$linenum.'">'.$value2.'</span> <img src="'.$GLOBALS["server_absolute_path"].$GLOBALS["direct"].'/calendar/calendar.gif" id="fe_'.$name.$linenum.'" style="cursor: pointer; vertical-align: text-bottom;" title="���������" />
	<script type="text/javascript">
		Calendar.setup({
			inputField     :    "f_'.$name.$linenum.'",     // id of the input field
			ifFormat       :    "%Y-%m-%d",     // format of the input field (even if hidden, this format will be honored)
			displayArea    :    "e_'.$name.$linenum.'",       // ID of the span where the date is to be shown
			daFormat       :    "%d.%m.%Y",// format of the displayed date
			button         :    "fe_'.$name.$linenum.'",  // trigger button (well, IMG in our case)
			align          :    "cR",           // alignment (defaults to "Bl")
			firstDay	   :	1,
			weekNumbers	   :	true,
			showOthers	   :	true,
			singleClick    :    true
		});
	</script></nobr>';

		return($content);
	}

	function destroy() {
		unset($this);
	}
}

?>